﻿namespace FirstGearGames.FlexSceneManager.LoadUnloadDatas
{


    public enum SceneScopeTypes
    {
        Networked = 0,
        Connections = 1
    }


}